module.exports = {
    mysql: {
        host: 'localhost',
        user: 'root',
        password: '1234',
        database:'crawl',
        // 最大连接数，默认为10
        connectionLimit: 10
    }
};